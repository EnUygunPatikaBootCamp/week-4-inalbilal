<?php
namespace App\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class RandomNumberCommand extends Command
{
    protected static $defaultName = 'app:create-random-number';

    protected function configure(): void
    {
        $this
            // Bu kısımda random_count adında olan bu inputtan üretilecek random sayıların miktarını belirleyecek bir sayı alıyoruz.
            ->addArgument('random_count', InputArgument::REQUIRED, 'Random Number Count')
        ;
    }


    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        // configure kısmında tanımladığımız inputtan gelen değeri $number_count değişkenine atıyoruz.
        $number_count = $input->getArgument("random_count");
        $number_array = [];

        // Burada ise $number_count'tan gelen değere kadar çalışacak bir döngü oluşturuyoruz.
        // Döngü içerisinde ise rand() fonksiyounu ile 1'den 1000'e kadar random sayılar üretip $number_array içerisinde topluyoruz.
        for ($i = 0; $i<$number_count; $i++)
        {
            $number_array[] = rand(1,1000);
        }

        // min() ve max() fonksiyonları ile $number_array'deki en büyük ve en küçük sayıları ekrana yazdırıyoruz.
        $output->writeln("En Büyük Sayı: " . max($number_array) . " En Küçük Sayı: " .  min($number_array));
        return Command::SUCCESS;

    }
}