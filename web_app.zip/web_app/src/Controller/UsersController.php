<?php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class UsersController extends AbstractController
{

    /**
     * @return Response
     * @Route("/users", name="users")
     */
    public function users(): Response
    {
        // Kullanıcı bilgilerinin olduğu array türünde $usersInfo adlı bir değişken ve sayfamızın başlığı olan $title'ı oluşturuyoruz
        $title = 'Users Table';
        $usersInfo = [
            array(
                "name" => "Bilal",
                "surname" => "İnal",
                "age" => 18,
                "department" => "Information Technology"
            ),
            array(
                "name" => "Ali",
                "surname" => "Veli",
                "age" => 45,
                "department" => "Human Resources"
            )
        ];

        // users.html.twig'i render edip parametre olarakta bu iki değişkeni gönderiyoruz.
        return $this->render('users.html.twig', [
            'title' => $title,
            'users_info' => $usersInfo,
        ]);
    }
}